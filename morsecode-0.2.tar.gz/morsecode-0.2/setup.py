from distutils.core import setup

setup(
    name='morsecode',
    version='0.2',
    author='Netherpills',
    url='https://github.com/netherpills/morsecode-py',
    packages=['morsecode',],
    license='MIT',
    long_description=open('README.txt').read(),
)
