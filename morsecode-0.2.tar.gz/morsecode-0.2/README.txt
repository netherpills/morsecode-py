This package translates from text to morse code and viceversa.

---Documentation---

CLASS morse(lettercase='upper')
The "lettercase" variable has just two answers: 'upper' or 'lower'.
This is for get the decoded text in uppercase or lowercase.

morse.encode(string or int)
With this command you encode any text to morse code.

morse.decode(string or int)
With this command you decode any morse code to text.