mlang = { 'A':'.-', 'B':'-...', 'C':'-.-.', 'D':'-..', 'E':'.',
          'F':'..-.', 'G':'--.', 'H':'....', 'I':'..', 'J':'.---', 'K':'-.-',
          'L':'.-..', 'M':'--', 'N':'-.', 'O':'---', 'P':'.--.', 'Q':'--.-',
          'R':'.-.', 'S':'...', 'T':'-', 'U':'..-', 'V':'...-', 'W':'.--',
              'X':'-..-', 'Y':'-.--', 'Z':'--..',
              '1':'.----', '2':'..---', '3':'...--',
              '4':'....-', '5':'.....', '6':'-....',
              '7':'--...', '8':'---..', '9':'----.',
              '0':'-----', ', ':'--..--', '.':'.-.-.-',
              '?':'..--..', '/':'-..-.', '-':'-....-',
              '(':'-.--.', ')':'-.--.-'} 

class morse:
    def __init__(self, lettercase):
        self.lettercase = lettercase

        assert (lettercase in ['upper', 'lower']), Exception(' Write "upper" or "lower".')
    
    def encode(self, text : str):        
        if isinstance(text, str):
            text = text.upper()
        elif isinstance(text, int):
            text = str(text)
        
        ntext = ''
        for l in text:
            if l != ' ':
                ntext = ntext + mlang[l] + ' '
            else:
                ntext = ntext + ' '

        return ntext

    def decode(self, text : str):
        if isinstance(text, str):
            text = text.upper()
        
        text = text + ' '
        ntext = ''
        ntext2 = ''

        for l in text:
            if (l != ' '):
                i = 0
                ntext2 = ntext2 + l
            else:
                i = i + 1
                if i == 2:
                    ntext = ntext + ' '
                else:
                    ntext = ntext + list(mlang.keys())[list(mlang.values()).index(ntext2)]
                    ntext2 = ''
                    
        if self.lettercase == 'lower' and isinstance(text, str):
            return ntext.lower()
        elif self.lettercase == 'upper' and isinstance(text, str):
            return ntext.upper()
        else:
            return ntext

